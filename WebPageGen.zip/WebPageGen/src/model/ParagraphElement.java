package model;

import java.util.ArrayList;

/**
 * 
 * Represents a paragraph (&lt;p&gt;) tag.  It relies on an
 * ArrayList in order to keep track of the set of Element objects
 * that are part of the paragraph.
 * @author UMCP
 *
 */
public class ParagraphElement extends TagElement {
	private ArrayList<Element> items;

	public ParagraphElement(String attributes) {
		super("p", false, new TextElement(attributes), attributes);
		items = new ArrayList<Element>();
	}

	public void addItem(Element item) {
		items.add(item);
	}

	@Override
	public String genHTML(int indentation) {
		StringBuffer paragraph = new StringBuffer();
		paragraph.append(Utilities.spaces(indentation) + this.getStartTag());
		for(Element element: items) {
			paragraph.append("\n"  + element.genHTML(indentation));
		}
		paragraph.append("\n" + this.getEndTag());
		return paragraph.toString();
	}
}
