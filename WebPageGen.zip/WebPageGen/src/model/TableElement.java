package model;

/**
 * Represents the &lt;table&gt tag.
 * A two dimensional array is used to keep track of the Element objects of table.
 * @author UMCP
 *
 */
public class TableElement extends TagElement {
	private Element[][] items;

	public TableElement(int rows, int cols, String attributes) {
		super("table", false, null, attributes);
		this.attributes = attributes;
		items = new Element[rows][cols];
	}

	public void addItem(int rowIndex, int colIndex, Element item) {
		items[rowIndex][colIndex] = item;
	}

	public double getTableUtilization() {
		int count = 0;
		for (int i = 0; i < items.length; i++) {
			for (int j = 0; j < items[i].length; j++) {
				if(items[i][j] != null) {
					count++;
				}
			}
		}
		return (double) count / (items.length * items[0].length) * 100;
	}

	public String genHTML(int indentation) {
		StringBuffer tableHTML = new StringBuffer();
		tableHTML.append(Utilities.spaces(indentation) + this.getStartTag() + "\n");
		for (int i = 0; i < items.length; i++) {
			tableHTML.append(Utilities.spaces(indentation) + "<tr>");
			for (int j = 0; j < items[i].length; j++) {
				tableHTML.append("<td>");
				if(items[i][j] == null) {
					tableHTML.append("");
				} else {
					tableHTML.append(items[i][j].genHTML(1));
				}
				tableHTML.append("</td>");
			}
			tableHTML.append("</tr>" + "\n");
		}
		tableHTML.append(Utilities.spaces(indentation) + this.getEndTag());
		return tableHTML.toString();
	}

}
