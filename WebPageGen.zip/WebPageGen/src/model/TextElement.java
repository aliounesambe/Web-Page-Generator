package model;

/**
 * 
 * Represents text that can appear in an HTML document
 * @author UMCP
 *
 */
public class TextElement implements Element {
	private String text;
	
	public TextElement(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public String genHTML(int indent) {
		StringBuffer indented = new StringBuffer("");
		for (int i = 0; i < indent; i++) {
			indented.append(" ");
		}
		return indented.toString() + text;
	}
}
