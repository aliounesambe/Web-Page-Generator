
package model;

/**
 * Represents the &lt;a&gt; tag.
 * @author UMCP
 *
 */
public class AnchorElement extends TagElement {
	private String linkText;
	private String url;


	public AnchorElement(java.lang.String url,
			java.lang.String linkText ,
			java.lang.String attributes) {
		super("a", true, new TextElement(linkText), attributes);
		this.url = url;
		this.linkText = linkText;
		if (attributes == null) {
			this.setAttributes​("href= " + "\"" + url + "\"");
		} else {
			this.setAttributes​("href= " + "\"" + url + "\"" + attributes);
		}
	}

	public java.lang.String getLinkText(){
		return this.linkText;
	}

	public java.lang.String getUrlText(){
		return this.url;
	}

	public java.lang.String genHTML(int indentation) {
		StringBuilder indented = new StringBuilder();
		for (int i = 0; i < indentation; i++) {
			indented.append(" ");
		}
		return indented.toString() + this.getStartTag() 
		+ ">" + linkText + this.getEndTag();
	}
}
