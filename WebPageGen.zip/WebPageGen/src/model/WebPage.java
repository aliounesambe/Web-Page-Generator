package model;

import java.util.*;

/**
 * Represents a web page.  Web page elements are
 * stored in an ArrayList of Element objects.  A title
 * is associated with every page.  This class implements
 * the Comparable interface.  Pages will be compared
 * based on the title.
 * @author UMCP
 *
 */
public class WebPage implements Comparable<WebPage> {
	private ArrayList<Element> elements;
	private String title;

	public WebPage(String title) {
		this.title = title;
		elements = new ArrayList<Element>();
	} 

	public int addElement(Element element) {
		if(!(element instanceof TagElement)) {
			return -1;
		}
		elements.add(element);
		return ((TagElement)element).getId();
	}

	public String getWebPageHTML(int indentation) {
		StringBuffer page = new StringBuffer();
		page.append( "<!doctype html>");
		page.append("\n" + "<html>"); 
		page.append("\n" + Utilities.spaces(indentation) + "<head>");
		page.append("\n" + Utilities.spaces(indentation*2) + "<meta charset=\"utf-8\"/>");
		page.append("\n" + Utilities.spaces(indentation*2) + "<title>" + title + "</title>");
		page.append("\n" + Utilities.spaces(indentation) + "</head>");
		page.append("\n" + Utilities.spaces(indentation) + "<body>");
		for(Element element: elements) {
			page.append("\n" + element.genHTML(indentation*2));
		}
		page.append("\n" + Utilities.spaces(indentation) + "</body>");
		page.append("\n" + "</html>");
		return page.toString();
	}

	public void writeToFile(String filename, int indentation) {
		Utilities.writeToFile(filename + " ",  indentation + title);
	}

	public Element findElem(int id) {
		for (Element element: elements) {
			if (((TagElement)element).getId() == id) {
				return element;
			}
		}
		return null;
	}

	public String stats() {
		int listCount = 0;
		int parCount = 0;
		int tableCount = 0;
		double tableUtilization = 0;

		for(Element element: elements) {
			if(element instanceof ListElement) {
				listCount++;
			} else if (element instanceof ParagraphElement) {
				parCount++;
			} else if (element instanceof TableElement) {
				tableCount++;
				tableUtilization += ((TableElement)element).getTableUtilization();
			}
		}
		StringBuffer stats = new StringBuffer();
		stats.append("List Count: " + listCount);
		stats.append("\n" + "Paragraph Count: " + parCount);
		stats.append("\n" + "Table Count: " + tableCount);
		stats.append("\n" + "TableElement Utilization: " + tableUtilization/tableCount);
		return stats.toString();
	}

	@Override
	public int compareTo(WebPage webPage) {
		if (this.title.compareTo(webPage.title) == 0) {
			return 0;
		} else if (this.title.compareTo(webPage.title) > 1) {
			return 1;
		} else {
			return -1;
		}
	}

	public static void enableId(boolean choice) {
		TagElement.enableId(choice);
	}
}
