package model;

import java.util.ArrayList;

/**
 * Represents the &lt;ul&gt and the &lt;ol&gt; tags.
 * An ArrayList is used to keep track of the Element objects of the list.
 * @author UMCP
 *
 */
public class ListElement extends TagElement {
	private ArrayList<Element> items;

	public ListElement(boolean ordered, String attributes) {
		super("ul", false, null, attributes);
		items = new ArrayList<Element>();
		if (ordered == true) {
			this.tagName = "ol";
		}
	}

	public void addItem(Element item) {
		items.add(item);
	}

	public String genHTML(int indentation) {
		StringBuffer list = new StringBuffer();
		list.append(Utilities.spaces(indentation) + this.getStartTag());
		for(Element element: items) {
			list.append("\n" + Utilities.spaces(indentation) + "<li>");
			list.append("\n" + Utilities.spaces(indentation) + element.genHTML(indentation));
			list.append("\n" + Utilities.spaces(indentation) + "</li>");
		}
		list.append("\n" + Utilities.spaces(indentation) + this.getEndTag());
		return list.toString();
	}
}
