package model;

/**
 * 
 * Represents an HTML tag element (<&lt;p&gt;, &lt;ul&gt;, etc.).
 * Each tag has an id (ids start at 1).  By default the start tag
 * will have an id (e.g., <&lt;p id="a1"&gt;&lt;/p&gt;) when
 * the HTML for the tag is generated.  This can be disabled by
 * using enableId.
 * @author UMCP
 *
 */
public class TagElement implements Element {
	protected String tagName;
	private boolean endTag;
	private Element content;
	protected String attributes;
	private static int id = 1;
	private int total = 0;
	private static boolean generateId = true;


	public TagElement(String tagName, boolean endTag, Element content, 
			java.lang.String attributes) {
		this.tagName = tagName;
		this.endTag = endTag;
		this.content = content;
		this.attributes = attributes;
		if(attributes == null) {
			this.attributes = "";
		} else {
			this.attributes = attributes;
		}
		total = id++;
	}


	public int getId() {
		return id;
	}


	public java.lang.String getStringId(){
		return " id=" + "\"" + tagName + total + "\"";
	}


	public java.lang.String getStartTag(){
		StringBuffer startTag = new StringBuffer();
		startTag.append("<" + tagName);
		if (generateId == true) {
			startTag.append(this.getStringId());
		}
		if (this.attributes != null) {
			startTag.append(" " + this.attributes);
		}
		if (this.tagName != "img" && this.tagName != "a") {
			startTag.append(">");
		}
		return startTag.toString();
	}


	public String getEndTag(){
		return "</" + tagName + ">";
	}


	public void setAttributes​(String attributes) {
		this.attributes = attributes;
	}


	public static void enableId(boolean choice) {
		generateId = choice;
	}


	public static void resetIds() {
		id = 1;
	}

	@Override
	public String genHTML(int indent) {
		StringBuffer indented = new StringBuffer("");
		for(int i = 0; i < indent; i++) {
			indented.append(" ");
		}
		if (endTag) {
			return indented.toString() + getStartTag() + content.genHTML(indent) + "</" + tagName + ">";
		} else {
			return indented.toString() + getStartTag() + content.genHTML(indent);
		}
	}
}